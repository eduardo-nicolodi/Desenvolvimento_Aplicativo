package com.example.menulista;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private ListView lista;
    private String[] itens = {"HTML5", "CSS", "SASS", "JavaScript", "NodeJs", "AngularJs","Ruby", "React", "jQuery"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //mapeamento da lista.
        lista = findViewById(R.id.lista);

        /*criar um adaptador para servir de ligação entre o array e o elemento  listView no xml
        o adaptador ven do atrubuto adapter
        android.R.layout.simple_list_item_1 mapeamento define o tipo da lista, ou seja uma listView simples - item1
        android.R.id.text1 mapeamento que define os tipos de valores da lista
        */

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, android.R.id.text1, itens);

        //adiciona o adapter para a lista criada
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Toast.makeText(MainActivity.this, itens[i], Toast.LENGTH_SHORT).show();

                switch (i)
                {
                    case 0:
                        abrirHtml();
                        break;
                }
            }
        });
    }

    private void abrirHtml()
    {
        Intent janela = new Intent(this, CursoHtml.class);
        startActivity(janela);
        finish();
    }
}