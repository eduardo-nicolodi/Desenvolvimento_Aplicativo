package com.eduardo.anime;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

public class Opening extends AppCompatActivity {
    private VideoView anime;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opening);

        anime = findViewById(R.id.anime);
        btnVoltar = findViewById(R.id.btnVoltar);

        Uri caminho = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.video);
        anime.setVideoURI(caminho);
        anime.start();

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });
    }
}