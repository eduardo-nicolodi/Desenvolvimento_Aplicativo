package com.eduardo.percy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Acampamento extends AppCompatActivity {
    private Button btnMapa, btnVoltar3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acampamento);

        btnMapa = findViewById(R.id.btnMapa);
        btnVoltar3 = findViewById(R.id.btnVoltar3);

        btnMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMapa();
            }
        });

        btnVoltar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar3();
            }
        });

    }

    public void abrirMapa(){
        Intent janela = new Intent(this, Mapa.class);
        startActivity(janela);
    }

    public void abrirVoltar3(){
        Intent janela = new Intent(this, Selecao.class);
        startActivity(janela);
    }
}