package com.eduardo.percy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Selecao extends AppCompatActivity {
    private Button btnTeste, btnAcampamento, btnVoltar;
    MediaPlayer mp = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao);

        btnTeste = findViewById(R.id.btnTeste);
        btnAcampamento = findViewById(R.id.btnAcampamento);
        btnVoltar = findViewById(R.id.btnVoltar);

        mp = MediaPlayer.create(this, R.raw.grega);
        mp.start();
        mp.setLooping(true);

        btnTeste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTeste();
            }
        });

        btnAcampamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirAcampamento();
            }
        });

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });
    }

    public void abrirTeste(){
        Intent janela = new Intent(this, Teste.class);
        startActivity(janela);
    }

    public void abrirAcampamento(){
        Intent janela = new Intent(this, Acampamento.class);
        startActivity(janela);
    }

    public void abrirVoltar(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }
}